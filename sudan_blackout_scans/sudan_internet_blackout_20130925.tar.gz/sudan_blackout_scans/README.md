This is the result of a combination of ZMap scans triggered to run against Sudanese IP prefixes every 15 minutes. 
Origin IP has been masked to: 85.25.0.0
A few results have been corrupted in process, those such be in inordinately small files. Probably just use your discretion.
-CDA
